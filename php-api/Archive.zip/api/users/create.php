<?php

// Super can create team_leader; team_leader can create staff
$payload = requireAuth();
$callerRole = $payload->role ?? 'end_user';
$allowedRoles = [];
if ($callerRole === 'super_admin') $allowedRoles = ['team_leader'];
elseif ($callerRole === 'team_leader') $allowedRoles = ['staff'];
else jsonError('Forbidden', 403);

// Optional: referral_code support for staff users (migration 006_users_referral_code.sql)
$hasUserReferralCode = false;
try {
    $stmt = getDb()->query("SHOW COLUMNS FROM users LIKE 'referral_code'");
    $hasUserReferralCode = $stmt && $stmt->rowCount() > 0;
} catch (Throwable $e) {}

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$name = trim($input['name'] ?? '');
$email = trim($input['email'] ?? '');
$password = $input['password'] ?? '';
$phone = trim($input['phone'] ?? '');
$role = trim($input['role'] ?? $allowedRoles[0]);

if (!$name || !$email || !$password) {
    jsonError('Name, email and password are required');
}

if (!in_array($role, $allowedRoles, true)) {
    jsonError('Invalid role. You may only create: ' . implode(', ', $allowedRoles));
}

if (strlen($password) < 8) {
    jsonError('Password must be at least 8 characters');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonError('Invalid email address');
}

$pdo = getDb();
$stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
$stmt->execute([$email]);
if ($stmt->fetch()) {
    jsonError('Email already registered', 409);
}

$hash = password_hash($password, PASSWORD_DEFAULT);
if ($hasUserReferralCode) {
    $referralCode = null;
    if ($role === 'staff') {
        try {
            $referralCode = 'STF' . strtoupper(bin2hex(random_bytes(3)));
        } catch (Throwable $e) {
            $referralCode = 'STF' . strtoupper(substr(md5(uniqid((string) $email, true)), 0, 6));
        }
    }
    $stmt = $pdo->prepare('INSERT INTO users (name, email, password, phone, role, referral_code) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([$name, $email, $hash, $phone ?: null, $role, $referralCode]);
} else {
    $stmt = $pdo->prepare('INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$name, $email, $hash, $phone ?: null, $role]);
}
$userId = (int) $pdo->lastInsertId();

$stmt = $pdo->prepare('SELECT id, name, email, phone, role, is_active, created_at FROM users WHERE id = ?');
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
$user['id'] = (int) $user['id'];

jsonSuccess($user, 'User created', 201);
